<?php $__env->startSection('title-page', 'Transaksi'); ?>
<?php $__env->startSection('title', 'Laporan Transaksi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Laporan Transaksi</h1>
    </div>
    
    <p class="mb-4">Date Runing</p>
    <div class="card shadow mb-4">
        <div class="card-header py-2">
            <h6 class="m-0 font-bold">Filter Search Tanggal</h6>
        </div>
        <div class="card-body">
            <form action="/laporan" method="<?php echo e(route('laporan.index')); ?>">
                <label class="py-2">Pilih Tanggal</label>
                <div class="row">
                    <div class="col">
                        <input class="form-control" type="date" name="tanggal" value="<?php echo e(request()->input('tanggal') ?? date('Y-m-d')); ?>">
                    </div>
                    <div class="col">
                        <button type="submit" class="btn  btn-primary">Search</button>
                        <?php if($tanggal): ?>
                            <a href="<?php echo e(route('laporan.index')); ?>" class="btn  btn-warning">Reset</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-sm-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">Total Barang</h5>
                    <p class="card-text fw-bold"><?php echo e($jumlahBarang); ?></p>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title">Total Pemasukan</h5>
                    <p class="card-text fw-bold"><?php echo e($totalHarga); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title m-0">Daftar Barang</h5>
                    <table class="table datatable">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Barang</th>
                            <th>Jumlah</th>
                            <th>Total Pemasukan</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $detailtransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->inventaris->nama_barang); ?></td>
                                <td><?php echo e($data->jumlah); ?></td>
                                <td><?php echo e($data->total); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kazuya Workspace\jayaindahperkasav2\jayaindahperkasa\resources\views/laporan/index.blade.php ENDPATH**/ ?>