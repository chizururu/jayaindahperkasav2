<?php

namespace App\Http\Controllers;

use App\Models\DetailTransaksi;
use App\Models\Inventaris;
use App\Models\Transaksi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;


class TransaksiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        //
        $tanggal = $request->input('tanggal');

        if(!$tanggal) {
            $tanggal = date('Y-m-d');
        }
        $transaksi = Transaksi::whereDate('created_at', $tanggal)->get();
        return view('transaksi.index', compact('transaksi', 'tanggal'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $inventaris = Inventaris::all();
        return view('transaksi.create')->with('inventaris', $inventaris);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validateData = $request->validate([
            'nama_pelanggan' => 'required',
            'total_harga' => 'required',
            'no_telepon' => 'required',
            'alamat' => 'required',

        ]);

        $transaksi = new Transaksi();
        $transaksi->nama_pelanggan = $validateData['nama_pelanggan'];
        $transaksi->total_harga = $validateData['total_harga'];
        $transaksi->no_telepon = $validateData['no_telepon'];
        $transaksi->alamat = $validateData['alamat'];
        $transaksi->save();

        $transaksi_id = $transaksi->id;
        $daftar_barang = json_decode($request->input('daftar_barang'),true);
        foreach ($daftar_barang as $barang) {
            $detailtransaksi = new DetailTransaksi();
            $detailtransaksi->transaksi_id = $transaksi_id;
            $detailtransaksi->inventaris_id = $barang['id'];
            $detailtransaksi->jumlah_barang = $barang['jumlah'];
            $detailtransaksi->sub_total = $barang['subharga'];
            $detailtransaksi->save();

            // Mengurangi
            $inventaris = Inventaris::find($barang['id']);
            $inventaris -> jumlah_stok -= $barang['jumlah'];
            $inventaris-> save();
        };
        return redirect()->route('transaksi.index')->with("info-add", "Order $transaksi->id, $transaksi->nama_pelanggan berhasil ditambahkan");
    }

    /**
     * Display the specified resource.
     */
    public function show(Transaksi $transaksi)
    {
        //
        $detailTransaksi = DetailTransaksi::where('transaksi_id', $transaksi->id)->get();
        return view('detailtransaksi.index', compact('transaksi', 'detailTransaksi'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Transaksi $transaksi)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Transaksi $transaksi)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Transaksi $transaksi)
    {
        //
    }
}
