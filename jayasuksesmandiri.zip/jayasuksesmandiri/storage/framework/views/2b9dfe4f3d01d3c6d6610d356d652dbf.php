<?php $__env->startSection('title-page', 'Transaksi'); ?>
<?php $__env->startSection('title', 'Form Transaksi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Detail Transaksi</h1>
    </div>
    <hr>
    <div class="card shadow mb-4">
        <div class="card-header py-2">
            <h5 class="card-title m-0">Informasi Pelanggan</h5>
        </div>
        <div class="card-body mt-2">
            <div class="py-4">
                <div class="row mb-2">
                    <label class="col-sm-4 col-form-label">Nomor Order</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="id" value ="<?php echo e($transaksi->id); ?>" disabled>
                    </div>
                </div>
                <div class="row mb-2">
                    <label class="col-sm-4 col-form-label">Nama Pelanggan</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="nama_pelanggan" value ="<?php echo e($transaksi->nama_pelanggan); ?>" disabled>
                    </div>
                </div>
                <div class="row mb-2">
                    <label class="col-sm-4 col-form-label">Nomor Telepon</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="no_telepon" value ="<?php echo e($transaksi->no_telepon); ?>" disabled>
                    </div>
                </div>
                <div class="row mb-2">
                    <label for="alamat" class="col-sm-4 col-form-label">Alamat</label>
                    <div class="col-sm-7">
                        <textarea id="alamat" class="form-control" style="height: 80px" value ="<?php echo e($transaksi->alamat); ?>" disabled></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Keranjang Barang</h5>
            <!-- Bordered Table -->
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama Barang</th>
                        <th scope="col">Jumlah Barang</th>
                        <th scope="col">Sub Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $detailTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($detail->inventaris->nama_barang); ?></td>
                            <td><?php echo e($detail->jumlah_barang); ?></td>
                            <td><?php echo e($detail->sub_total); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- End Bordered Table -->
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-2">
            <h5 class="card-title m-0">Pembayaran</h5>
        </div>
        <div class="card-body mt-2">
            <div class="py-4">
                <div class="row mb-2">
                    <label class="col-sm-4 col-form-label">Total Harga</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" value="<?php echo e($transaksi->total_harga); ?>" disabled>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kazuya Workspace\jayaindahperkasav2\jayaindahperkasa\resources\views/detailtransaksi/index.blade.php ENDPATH**/ ?>